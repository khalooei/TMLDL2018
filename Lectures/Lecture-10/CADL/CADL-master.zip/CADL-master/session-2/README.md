# Session 2 - Training a network w/ Tensorflow
<p class="lead">
Assignment: Teaching a Network to Paint
</p>

This second homework assignment is contained in the [session-2.ipynb](session-2.ipynb) notebook file.  If you are unsure of how to use notebook, please first follow the [installation instructions](../README.md#installation-preliminaries).

And follow the instructions on getting notebook running.

Then come back here and work through the notebook [session-2.ipynb](session-2.ipynb).  If you have any questions, be sure to enroll in the course and ask your peers in the \#CADL community or me on the forums!

https://www.kadenze.com/courses/creative-applications-of-deep-learning-with-tensorflow/info
