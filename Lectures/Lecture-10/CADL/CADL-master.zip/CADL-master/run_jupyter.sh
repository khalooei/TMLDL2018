#!/usr/bin/env bash
jupyter notebook "$@"
