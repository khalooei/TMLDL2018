This code is part of the Kadenze Academy course on "Creative Applications of Deep Learning with Tensorflow" taught by Parag K. Mital.  More information can be found on the course website: https://www.kadenze.com/courses/creative-applications-of-deep-learning-with-tensorflow/info and the course github: https://github.com/pkmital/CADL

